package jwtc.android.chess;

public class ImageCacheObject{
	
	public int _piece, _color, _fieldColor;
	public boolean _bPiece, _selectedPos, _selected;
	public String _coord;
	
	public static boolean _flippedBoard = false;
	
	public ImageCacheObject(){
		
	}
}