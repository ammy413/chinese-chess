package jwtc.chess.board;

public class BoardMembers extends BoardStatics 
{
}
