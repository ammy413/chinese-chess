ChineseChess4Android
====================

a android version of the Chinese Chess game, which is not very difficult to defeat